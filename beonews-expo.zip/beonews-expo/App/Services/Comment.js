import CommentModal from "./CommentModal";

var Comment = new CommentModal();
export default Comment;
