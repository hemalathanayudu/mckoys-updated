import Constants from "./Constants";


// more explaination here
// support Editor's pick like Apple news - swipe

export default [
  Constants.Layout.column,
  Constants.Layout.column,
  Constants.Layout.column,

  Constants.Layout.list,
  Constants.Layout.list,
  Constants.Layout.list,
  Constants.Layout.list,

  Constants.Layout.card,
  Constants.Layout.column,
  Constants.Layout.column,
  Constants.Layout.column,
  Constants.Layout.column,
  Constants.Layout.simple,
  Constants.Layout.simple,
  Constants.Layout.simple,
  Constants.Layout.simple,
  Constants.Layout.card,
]